<?php
$conn =mysqli_connect('localhost','root','')or die(mysqli_error());
$db=mysqli_select_db($conn,'hostel')or die(mysqli_error($conn));
?>