<? $country=intval($_GET['country']);
$link = mysqli_connect('localhost', 'root', ''); //changet the configuration in required
if (!$link) {
    die('Could not connect: ' . mysqli_error($conn));
}
mysqli_select_db('db_ajax');
$query="SELECT id,statename FROM state WHERE countryid='$country'";
$result=mysqli_query($conn,$query);

?>