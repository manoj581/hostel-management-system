<?php 

$conn =mysqli_connect("localhost", "root", "")or die(mysqli_error($conn));
$db =mysqli_select_db($conn,'hostel')or die(mysqli_error($conn));

$fees_type = $_POST['get_option'];
     $sql="SELECT `cost` FROM `fees_structure` WHERE fees_type='$fees_type'";
     $find=mysqli_query($conn,$sql);
     $row=mysqli_fetch_array($find);
     
       echo $row['cost'];


?>