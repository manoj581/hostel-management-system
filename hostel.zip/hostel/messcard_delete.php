<?php 
$delete =$_GET['id'];
$conn =mysqli_connect("localhost","root","")or die(mysqli_error());
$db =mysqli_select_db($conn,'hostel')or die(mysqli_error($conn));

$delete ="DELETE FROM `messcard` WHERE id='$delete'";
$result =mysqli_query($conn,$delete);
echo '<meta http-equiv="refresh" content="0;url=messcard_view.php">';


?>