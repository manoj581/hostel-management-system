<!DOCTYPE html>
<html lang="en">
<head>
    <title>Student Entry</title>
</head>


<body>

<?php 
include 'header.php';
include 'left_side_bar.php';

//print_r($_POST);
//die();

     $conn=mysqli_connect("localhost","root","")or die(mysqli_error());
     $db=mysqli_select_db($conn,'hostel')or die(mysqli_error($conn));
     
    if (isset($_POST['upload'])) {

    $security=$_POST['security'];
    $course=$_POST['course'];
    $name=$_POST['username'];
    $birthdate=$_POST['birthdate'];
    $join=$_POST['join'];
    $fname=$_POST['fname'];
    $mname=$_POST['mname'];
    $gender=$_POST['gender'];
    $address=$_POST['address'];
    $number=$_POST['number'];
    $pnumber=$_POST['pnumber'];
    $blood=$_POST['blood'];
    $status=$_POST['status'];

    $query="INSERT INTO `student`(`id`, `security`,  `course`, `name`, `dob`, `join`, `fname`, `mname`, `gender`, `address`, `contact`, `pnumber`, `blood`, `status`) VALUES ('','$security','$course','$name','$birthdate','$join','$fname','$mname','$gender','$address','$number','$pnumber','$blood','$status')";

// $query = mysqli_query($conn,"INSERT INTO student (id, course, name, dob, join, fname, mname, gender, contact, pnumber, blood, status) VALUES ('', '$course', '$name', '$birthdate', '$join', '$fname', '$mname', '$gender', '$address', '$number', '$pnumber', '$blood', '$status')")or die(mysql_errno());    

    
    $sel =mysqli_query($conn,$query)or die(mysqli_error($conn));
     echo '<meta http-equiv="refresh" content="0;url=student_add.php">';
 
 }
 else{
echo "student not create";

    }
   
   mysqli_close($conn);

?>
</body>

</html>