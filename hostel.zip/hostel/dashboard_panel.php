<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Hostel Management System</title>

    <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Timeline CSS -->
    <link href="../dist/css/timeline.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../bower_components/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>


        <div id="page-wrapper" style="
  background-image: linear-gradient(to right, #1D4350,#A43931); color:#fff;
">  
            <div class="row" style="padding-bottom: 10px;">
                <div class="col-lg-12">
                    <h1 class=" text-white "  style="color:#fff;">Dashboard</h1>
                </div>
                <!-- /.col-lg-12 -->
                <div class="col-lg-12">
                    <h1 style="border-bottom: 2px solid #fff;border-left: 5px solid transparent;padding: 5px 0px 5px 0px;width: 300px; border-radius: 20px 1px;text-align:center;">Welcome <?php echo ucfirst($_SESSION['username']); ?></h1>
                </div>
            </div>
            <!-- /.row --><br>
    <div class="row jumbotron" style="background: rgba(0,0,0,0.2); border-radius: 50px;
   color:#fff;padding: 10px 25px; margin: 2px 1px;
">
    <h2 style="border-left: 5px solid transparent;padding: 10px 2px 10px 10px;border-bottom: 1px solid #fff;width:450px;border-radius: 20px 1px;">Hostel Management System</h2>
    <p class="text-left" style="padding-left: 20px;">
       HMS is a software developed for managing various activities in the hostel.
    </p>
    </div>
    
     <div class="row float-right">
               <div class="col-md-8 col-xs-8 col-lg-8 col-sm-12 jumbotron text-center" style="background: rgba(0,0,0,0.2); border-radius: 50px;
   color:#fff;padding: 10px 15px; margin: 2px 1px; box-sizing: border-box;
">
                   
               </div>
               
                <div class="col-md-3 col-xs-3 col-lg-3 col-sm-3 float-right jumbotron text-left" style="background: rgba(0,0,0,0.2); border-radius: 40px;
   color:#fff;padding: 10px 15px 10px 20px; margin: 2px 1px;
"><?php 
                    include 'conn.php';
                    $sql = "SELECT * FROM student ORDER BY id DESC LIMIT 5";
                    $result = mysqli_query($conn,$sql);
                    echo "<ol><h3 class='text-left'>Recently joined Students </h3>";
                    while($row = mysqli_fetch_assoc($result)){
                        echo "<li style='font-size: 20px;'>".$row['name']."</li>";
                    }
                    echo "</ol";
                    
                    ?>
                </div>
            </div><br>
            
    </div>
    <div class="text-center row" title="Designed by Bootstrap developed by PSV_GU8">
                <div class="col-12" style="background: rgba(0,0,0,0.2); border-radius: 40px;
   color:#fff;padding: 10px 15px 10px 20px; margin: 2px 1px;
">             <h2>Project Designed and Developed by <span style="color: #1abc9d;" >Madan M R</span> and <span style="color: #1abc9d;">Kiran Kumar K</span></h2>
                </div>
            </div>
    <!-- /#wrapper -->


    <!-- jQuery -->
    <script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="../bower_components/raphael/raphael-min.js"></script>
    <script src="../bower_components/morrisjs/morris.min.js"></script>
    <script src="../js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
