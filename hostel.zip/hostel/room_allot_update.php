<?php 
$conn =mysqli_connect("localhost","root","") or die(mysqli_errno());
$db =mysqli_select_db($conn,'hostel')or die(mysqli_errno($conn));

if (isset($_POST['upload'])) {
    
    $allotup =$_POST['allotup'];
    $block =$_POST['block'];
    $roomno =$_POST['room'];
    $beds =$_POST['beds'];
    $name =$_POST['name'];
    $status =$_POST['status'];

    $up ="UPDATE `room_allotment` SET `block`='$block',`name`='$name',`roomno`='$roomno',`beds`='$beds',`status`='$status' WHERE id='$allotup'";
    $result=mysqli_query($conn,$up)or die(mysqli_error($conn));
    echo '<meta http-equiv="refresh" content="0;url=room_allot_view.php">';
}



?>