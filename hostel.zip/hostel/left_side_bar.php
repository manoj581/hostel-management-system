<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Hostel Management System</title>

    <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Timeline CSS -->
    <link href="../dist/css/timeline.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../bower_components/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body style="background:#222;">

    
     <div class="navbar-inverse sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                       <li class="text-center">
                           <h3 style="color:#e3e3e3; border: 5px double white;border-radius: 30px 0px;padding: 10px;margin: 10px 10px 40px 10px; ">HMS - Dashboard</h3>
                       </li>
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                <button class="btn btn-primary" type="button" style="color: #fff;;">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                            </div>
                            <!-- /input-group -->
                        </li>
                        <li>
                            <a href="login.php" style="color:#008780;"><i class="menu-icon fa fa-home"></i> Home</a>
                        </li>
                        <li>
                            <a href="#" style="color:#008780;"><i class="menu-icon fa fa-users" ></i> Fees<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="fees.php" style="color:#008780;"> Fees Structure</a>
                                </li>
                                <li>
                                    <a href="fees_view.php" style="color:#008780;">View Structure</a>
                                </li>
                                <li>
                                    <a href="fees_monthly.php" style="color:#008780;">Monthly Rent</a>
                                </li>
                                <li>
                                    <a href="fees_monthly_view.php" style="color:#008780;">View Monthly Bill</a>
                                </li>
                                                                
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        
                        <li>
                            <a href="#"style="color:#008780;"><i class="glyphicon glyphicon-qrcode" style="color:#008780;"></i> Block<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="block_add.php" style="color:#008780;"> Add Block</a>
                                </li>
                                <li>
                                    <a href="block_view.php" style="color:#008780;">View Block</a>
                                </li>
                                
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                       

                        <li>
                            <a href="#"style="color:#008780;"><i class="glyphicon glyphicon-inbox" style="color:#008780;"></i> Rooms<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="room_add.php" style="color:#008780;"> Add Rooms</a>
                                </li>
                                <li>
                                    <a href="room_view.php" style="color:#008780;">View Rooms</a>
                                </li>
                                <li>
                                    <a href="room_allot.php" style="color:#008780;">Allot Rooms</a>
                                </li>
                                <li>
                                    <a href="room_allot_view.php" style="color:#008780;">View rooms allotment</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                       

                        <li>
                            <a href="#" style="color:#008780;"><i class="glyphicon glyphicon-registration-mark" style="color:#008780;"></i> Student<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="student_add.php" style="color:#008780;">Registration</a>
                                </li>
                                <li>
                                    <a href="student_view.php" style="color:#008780;">View</a>
                                </li>
                                <li>
                                    <a href="messcard.php" style="color:#008780;">Mess Card</a>
                                </li>
                                <li>
                                    <a href="messcard_view.php" style="color:#008780;">View Messcard</a>
                                </li>
                                
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="report.php" style="color:#008780;"><i class="menu-icon fa fa-user" style="color:#008780;"></i> Report</a>
                            
                        </li>
                    </ul>
                       
                </div>
         </div>
    
           
    <!-- jQuery -->
    <script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="../bower_components/raphael/raphael-min.js"></script>
    <script src="../bower_components/morrisjs/morris.min.js"></script>
    <script src="../js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
