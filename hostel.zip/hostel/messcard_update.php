<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
       <?php 
      // include 'header.php';
     //  include 'left_side_bar.php';
      $conn = mysqli_connect("localhost", "root", "")or die(mysqli_errno());
      $db =mysqli_select_db($conn,'hostel')or die(mysqli_errno($conn));
      if (isset($_POST['upload'])) {
      	// for update use mess id
      	$mess1 =$_POST['mess'];

          $name =$_POST['name'];
          $food =$_POST['food'];
          $messcard =$_POST['messcard'];
          $startdate =$_POST['startdate'];
          $enddate =$_POST['enddate'];
          $status =$_POST['status'];

$query ="UPDATE `messcard` SET `name`='$name',`food`='$food',`messcard`='$messcard',`startdate`='$startdate',`enddate`='$enddate',`status`='$status' WHERE `id`='$mess1'";
    $mess =mysqli_query($conn,$query)or die(mysqli_error($conn));

  echo '<meta http-equiv="refresh" content="0;url=messcard_view.php">';

      }
      else {
        echo "messcard is not update";
      }
      mysqli_close($conn);

       ?>
</body>
</html>