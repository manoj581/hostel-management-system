<!DOCTYPE html>
<html lang="en">
<head>
    <title>Student Entry</title>
</head>


<body>

<?php 
include 'header.php';
include 'left_side_bar.php';

     $conn=mysql_connect("localhost","root","")or die(mysqli_error());
     $db=mysql_select_db('hostel2',$conn)or die(mysqli_error());
     if (isset($_POST['upload'])) {

        $block =$_POST['block'];
        $gender =$_POST['gender'];
        $description =$_POST['description'];
        $status =$_POST['status'];

        $query = "INSERT INTO block (id, block, gender, description,status)
VALUES ('','$block', '$gender', '$description', '$status')";    

    $set=mysqli_query($conn,$query);
     header('location:block_add.php');
 
 }
 else{
echo "block not create";

    }


    
    
   
   mysql_close($conn);

?>
</body>

</html>