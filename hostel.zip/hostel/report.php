<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Fees</title>
  <!-- ============================ date picker ==================== --> 
  

    
 <!-- ============================ /date picker ==================== --> 

    <!-- Bootstrap Core CSS -->
    <link href="bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="bower_components/datatables-responsive/css/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->


<!-- =================for get student details======================= -->
<script type="text/javascript">

function showreport(val)
{
 // alert(val); 
 $.ajax({
     type: 'post',
     url: 'get_report_bill.php',
     data: {
       get_option:val
     },
     success: function (response) {
   //    alert(response);
       document.getElementById("txtHint").innerHTML=response; 
     }
   });
}
</script>
<!-- =================/for get student details======================= -->
</head>
<body>
<?php  
 
include 'header.php';
include 'left_side_bar.php';
?>
    <div id="page-wrapper" style="   background-image: linear-gradient(to right, #1D4350,#A43931);; "> 
            <div class="row">
                <div class="col-lg-12">
                    <h1 class=" text-white "  style="color:#fff;">Fees</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12" style="background: transparent">
                    <div class="panel panel-default" style="background: rgba(0,0,0,0.4);color:#fff;">
                        <div class="panel-heading">
                            Block View
                        </div>
                        <!-- /.panel-heading -->
                <div class="panel-body">
                <div class="dataTable_wrapper">
              


<!-- ==================================== class="form-group"> ===================== -->
                        
            <div class="form-group">

<!-- ---------------------- form use for get report in Excel file ------------------ --> 
                <div class="form-group">                                          
                        <form id="form1" name="form1" method="post" action="ExportExcel.php">
                            <label> Export excel file now. Click the Get Report button below</label><br><br>
                            <button style="margin-left:150px;" type="submit" name="getReport" class="btn btn-success dropdown-toggle"> Get Report</button>
 <?php // <input type="submit" name="getReport" id="getReport" style="border: solid 1px #E0451F; background:#E0451F; font-weight:bold; color:#FFF;" value="Get Report" />
 ?>
                            
                        </form>
                </div>

<!-- ---------------------- form use for get report in Excel file ------------------ -->   
                                
            </div>

                </div>
                            <!-- /<div class="dataTable_wrapper"> -->
                           
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
                responsive: true
        });
    });
    </script>

</body>

</html>
