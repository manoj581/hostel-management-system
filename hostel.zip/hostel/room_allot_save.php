<!DOCTYPE html>
<html lang="en">
<head>
    <title>Student Entry</title>
</head>


<body>

<?php 
include 'header.php';
include 'left_side_bar.php';

//print_r($_POST);
//die();

     $conn=mysqli_connect("localhost","root","")or die(mysqli_error());
     $db=mysqli_select_db($conn,'hostel')or die(mysqli_error($conn));
     
    if (isset($_POST['upload'])) {

    $block=trim($_POST['block']);
    $name=trim($_POST['name']);
    $roomno=trim($_POST['room']);
    $beds=trim($_POST['beds']);
    $status=trim($_POST['status']);
    

    $query="INSERT INTO `room_allotment`(`id`, `block`, `name`, `roomno`, `beds`, `status`) VALUES ('','$block','$name','$roomno','$beds','$status')";
    
    $sel =mysqli_query($conn,$query)or die(mysqli_error($conn));

    $up=mysqli_query($conn,"update room set status=' $status' where beds='$beds' && block='$block' && roomno='$roomno' && block='$block'")or die(mysqli_error($conn));

    $up=mysqli_query($conn,"update student set status=' $status' where name='$name'")or die(mysqli_error($conn));

    echo " <meta http-equiv='refresh' content='0;url=room_allot.php'>";
 
 }
 else{
echo "room not allotment";

    }
   
   mysqli_close($conn);

?>
</body>

</html>