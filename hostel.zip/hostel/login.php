<?php 
include 'header.php';
include 'left_side_bar.php';
include 'dashboard_panel.php';
 
?>