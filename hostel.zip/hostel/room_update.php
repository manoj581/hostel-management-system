<!DOCTYPE html>
<html lang="en">
<head>
    <title>Student Entry</title>
</head>


<body>

<?php 
//include 'header.php';
//include 'left_side_bar.php';

//print_r($_POST);
//die();
     
     $conn=mysqli_connect("localhost","root","")or die(mysqli_error());
     $db=mysqli_select_db($conn,'hostel')or die(mysqli_error($conn));
     
    if (isset($_POST['upload'])) {

    $room = $_POST['rupdate'];

    $block=$_POST['block'];
    $roomno=$_POST['roomno'];
    $beds=$_POST['beds'];
    $description=$_POST['description'];
    $status=$_POST['status'];
    

    $update = "UPDATE `room` SET `roomno`='$roomno',`block`='$block',`beds`='$beds',`description`='$description',`status`='$status' WHERE id='$room'";
    $sel =mysqli_query($conn,$update)or die(mysqli_error($conn));
        echo '<meta http-equiv="refresh" content="0;url=room_view.php">';
 
 }
 else{
echo "room  not update";

    }
   
   mysqli_close($conn);

?>
</body>

</html>