<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
       <?php 
      
      $conn = mysqli_connect("localhost", "root", "")or die(mysqli_errno());
      $db =mysqli_select_db($conn,'hostel')or die(mysqli_errno($conn));
      if (isset($_POST['upload'])) {
        // for fetch fees structure for update
          $fees_structure=$_POST['fees_structure'];

          $fees =$_POST['fees'];
          $cost =$_POST['cost'];
          

  $update="UPDATE `fees_structure` SET `fees_type`='$fees',`cost`='$cost' WHERE id='$fees_structure'";
    $mess =mysqli_query($conn,$update)or die(mysqli_error($conn));
    // $fees_structure;
    

          echo '<meta http-equiv="refresh" content="0;url=fees_view.php">';

      }
      else {
        echo "fees_structure is not add";
      }
      mysqli_close($conn);

       ?>
</body>
</html>